
public class Typecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int i1 = 9;
		
		byte b1 = 11;
		
		System.out.println(i1);
		
		// converting byte to int
		i1 = b1;
		
		System.out.println(i1);
		
		byte a=10;
		float b=a;
		System.out.println(b);
		
		double c=10.12;
		int d =(int)c;
		System.out.println(d);
	}

}
