
public class Method {
	public void display1() {
		System.out.println("welcome to coding");
	}
public void display2(int value) {
	System.out.println("value: +"+value);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Method obj =new Method();
		obj.display1();
		obj.display2(40);

	}

}
