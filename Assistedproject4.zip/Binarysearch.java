package assistedproject4;

import java.util.Arrays;


public class Binarysearch {
	public static void main(String args[]){  
		int num = 30;
		int arr[] = {11,22,30,44,55};  
		int result = Arrays.binarySearch(arr,num);  
        if (result < 0)  
            System.out.println("Element is not found!");  
        else  
            System.out.println("Element is found at index: "+result);  
    }  
}  
