package Assitedproject3;

import java.util.LinkedList;
import java.util.Queue;
public class QueueProg {
	
    public static void main(String[]args)
    {
      Queue<String> qobj=new LinkedList<String>();
       qobj.add("RR");
       qobj.add("Finolex");
       qobj.add("polycab");
       qobj.add("aquasub");
       qobj.add("CRI");
       System.out.println("Queue head = " + qobj.element());
       System.out.println("Removing element from queue = " + qobj.remove());
       System.out.println("After removing head of queue = " + qobj);

}

}