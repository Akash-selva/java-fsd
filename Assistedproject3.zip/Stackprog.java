package Assitedproject3;

import java.util.Stack;
public class Stackprog {
public static void main(String[]args) {
Stack qobj=new Stack();
qobj.push("CRI");
qobj.push("TEXMO");
qobj.push("TARRO");
qobj.push("CROMPTON");

System.out.println("The total elements are "+qobj);
System.out.println("The elements popped is "+qobj.pop());
System.out.println("The Remaining elements are "+qobj);
}
}

