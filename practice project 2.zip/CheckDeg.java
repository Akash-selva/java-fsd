package handingProgram;

public class CheckDeg {
	public static void main(String[] args) throws Exception

	{

		try {

			int a,b;
		    a=18; b=8;

			System.out.println("res=" + a / b);

			Thread.sleep(3000);

		}

		catch (Exception e) {

			System.out.println(e);

		}

		finally

		{

			System.out.println("welcome to java");

		}

	}

	}

	