package oops;

class employee{
void dis1() {
System.out.println("Name of employee is akash");

}
}
class Details extends employee {
void dis2() {
System.out.println("The total performace of employee is high");
}
}
public class Inheritance {

public static void main(String[] args) {
employee obj1=new employee();
obj1.dis1();
Details obj2=new Details();
obj2.dis2();
obj2.dis1();

}

}
