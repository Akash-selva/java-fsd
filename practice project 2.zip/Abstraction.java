package oops;

abstract class Car{
abstract void mileage();
void colour() {
System.out.println("grey");
}
}
class Maruthi extends Car{
void speed() {
System.out.println("100km/hr");
}
void mileage() {
System.out.println("87km/hr");
}


}
public class Abstraction {

public static void main(String[] args) {
Maruthi obj=new Maruthi();
obj.speed();
obj.mileage();
obj.colour();



}
}

