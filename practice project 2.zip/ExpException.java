
public class ExpException {
	public static void main(String[] args) {
		int balance=10000;
		try {
		if(balance>0) {
		throw new Exception("Insufficient balance");
		}
		}catch(Exception e) {
		System.out.println(e);
		}


		}
}
