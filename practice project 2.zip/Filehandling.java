import java.io.File;

import java.io.FileWriter;

import java.io.BufferedWriter;

import java.util.Scanner;

public class Filehandling

{

	public static void main(String[] args)

	{

		File obj = new File("D://hello world.txt");

		try {
			if (obj.exists())

			{

				FileWriter fwrite = new FileWriter(obj);

				fwrite.write("hello everyone");

				BufferedWriter fupdate = new BufferedWriter(fwrite);

				String data = "hi! welcome to java";

				fupdate.append(data);

				System.out.println("append successfully");

				fupdate.close();

				fwrite.close();

				Scanner sc = new Scanner(obj);

				while (sc.hasNext())

				{

					String text = sc.nextLine();

					System.out.println("content in file: " + text);

				}
				sc.close();

				File del = new File("myworld.txt");

				if (del.delete())

				{

					System.out.println(del.getName() + " file deleted successfully");

				}

			}

			else if (obj.createNewFile())

			{

				System.out.println(obj.getName() + " file created successfully");

			}

		}

		catch (Exception e)

		{

			System.out.println(e);

		}

	}

}
