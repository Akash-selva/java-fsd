class Number {

	synchronized void printno(int n)

	{

		for (int i = 1; i <= 5; i++)

		{

			System.out.println(n * i);

		}

		try {

			Thread.sleep(3000);

		} catch (Exception e)

		{

			System.out.println(e);

		}

	}

}

class Number1 extends Thread {

	Number t;

	Number1(Number t)

	{

		this.t = t;

	}

	public void run()

	{

		t.printno(5);

	}

}

class Number2 extends Thread {

	Number t;

	Number2(Number t)

	{

		this.t = t;

	}

	public void run()

	{

		t.printno(10);

	}

}

public class SynchroEg {

	public static void main(String[] args)

	{

		Number myobj = new Number();

		Number1 obj1 = new Number1(myobj);

		Number2 obj2 = new Number2(myobj);

		obj1.start();

		obj2.start();

	}

}