
class Ex extends Exception

{

	public Ex()

	{

		System.out.println("hello");

	}

	public Ex(String msg)

	{
		super(msg);// for passing the custom message to super class

		String text = msg;

		System.out.println("valid " + text);

	}

}

public class ThrowEg {

	public static void main(String[] args)

	{

		try {

			int a = 10;

			int b = 2;

			if (a > b)

			{

				throw new Ex("a>b");// custom exception and message

			}

		}

		catch (Exception e)

		{

			System.out.println(e);

		}

	}

}
