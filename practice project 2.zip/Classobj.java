package oops;

class Company{
    void display1(int EmpId,String name) {
   System.out.println("EmpID is "+EmpId);
   System.out.println("Name is "+name);

    }
}
public class Classobj {
public static void main(String[]args) {
Company obj=new Company();
obj.display1(4012,"shaf");

}


}
