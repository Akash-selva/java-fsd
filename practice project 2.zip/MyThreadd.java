package thread;

public class MyThreadd extends Thread{
public void display() {
System.out.println("this is java programming");
}

public static void main(String[] args) {
MyThreadd obj=new MyThreadd();
obj.display();


}

}
