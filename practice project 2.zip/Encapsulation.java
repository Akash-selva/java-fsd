package oops;

class Perimeter{
int length;
int breadth;
Perimeter(int length,int breadth){
this.length=length;
this.breadth=breadth;
}
void getPerimeter() {
int Perimeter=2*(length+breadth);
System.out.println("The perimeter of rectangle is "+Perimeter);
}
}
public class Encapsulation {

public static void main(String[] args) {
Perimeter obj=new Perimeter(40,60);
obj.getPerimeter();



}

}
