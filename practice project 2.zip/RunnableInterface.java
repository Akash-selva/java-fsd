package thread;

class X implements Runnable{
public void run() {
for(int i=0;i<5;i++) {
System.out.println("Main "+i);
}
}
}
class Y implements Runnable{
public void run() {
for(int j=0;j<5;j++) {
System.out.println("Sub "+j);
}

}
}
public class RunnableInterface {
public static void main(String[]args) {
X obj1=new X();
Y obj2=new Y();
Thread t1=new Thread(obj1);
Thread t2=new Thread(obj2);
t1.start();
t2.start();
}

}
